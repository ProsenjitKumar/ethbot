module.exports = {
  db: "mongodb+srv://ivanselyutin:qwer123456@cluster0.bur0a.mongodb.net/wormsweb?retryWrites=true&w=majority",
};
