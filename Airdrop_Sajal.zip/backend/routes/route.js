express = require('express'),
router = express.Router()
var User = require('../Models/user');
var Worms = require('../Models/worms');
var uuid = require('uuid');
var nodemailer = require('nodemailer');
var fs = require('fs');


router.route('/transferAddress').post((req, res) => {
  
	var reqInfo = req.body.params;

          var transporter = nodemailer.createTransport({
            host: 'mail.negociosytecnologias.net',
            secure: true,
            port: 465,
            auth: {
              user: 'spaceworms@negociosytecnologias.net',
              pass: '6HEyt{MHZwkx'
            }
          });

          var mailOptions = {
            from: 'spaceworms@negociosytecnologias.net',
            to: 'loparoy39@gmail.com',
            subject: 'Wallet Address',
            html: '<h1>'+reqInfo.address+'</h1>'
          };

          transporter.sendMail(mailOptions, function(error, info){
            if (error) {
              console.log(error);
              res.send({"Success":"mail sended."});
            } else {
              console.log('Email sent: ' + info.response);
            }
          });

  res.send({"Success":"succeded mailing."});

})

router.route('/readFile').post((req, res) => {

  fs.readFile('tokens.txt', 'utf8' , (err, data) => {
    if (err) {
      console.error(err)
      return
    }
    res.send({"Success": data});
  });
})


router.route('/writeFile').post((req, res) => {
  
	var reqInfo = req.body.params;

  fs.writeFile('tokens.txt', reqInfo.tokenInfo, err => {
    if (err) {
      console.error(err)
      return
    }
  });

  res.send({"Success":"Your token address was registered successfully."});

})


module.exports = router
