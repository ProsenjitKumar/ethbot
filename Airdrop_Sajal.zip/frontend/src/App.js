import './App.css';
import {
  BrowserRouter as Router,
  Switch,
  Route,
} from "react-router-dom";
import Admin from './views/Admin';
import Mint from './views/Mint';

function App() {
  return (
    <Router>
      <Switch>
        <Route exact path="/" component={Mint} />
        <Route exact path="/admin" component={Admin} />
      </Switch>
    </Router>
  );
}

export default App;
